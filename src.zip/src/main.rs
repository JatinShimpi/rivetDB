use std::collections::{BinaryHeap, HashMap, VecDeque};
use std::io::{self, BufRead, BufReader, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Instant;

// Import from our modules
use rivetdb::commands::process_command;
use rivetdb::protocol::{frame_to_command, parse_frame};
use rivetdb::{EvictionPolicy, ServerState, SharedState};

fn main() {
    let listener = TcpListener::bind("127.0.0.1:7878").expect("failed to bind to address");
    println!("server listening on 127.0.0.1:7878");

    let state = Arc::new(Mutex::new(ServerState {
        db: HashMap::new(),
        expiries: BinaryHeap::new(),
        expired_count: 0,

        command_count: HashMap::new(),
        command_time_ns: HashMap::new(),
        slowlog: VecDeque::with_capacity(128),
        key_access_count: HashMap::new(),

        max_memory: 64 * 1024 * 1024, // 64 MB default
        eviction_policy: EvictionPolicy::AllKeysLFU,
    }));

    rivetdb::commands::expiry::start_expiry_thread(Arc::clone(&state));

    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                println!("new connection: {}", stream.peer_addr().unwrap());

                let state_clone = Arc::clone(&state);
                thread::spawn(move || {
                    handle_connection(stream, state_clone);
                });
            }
            Err(e) => {
                eprintln!("failed to establish a connection: {}", e);
            }
        }
    }
}

fn handle_connection(stream: TcpStream, state: SharedState) {
    let mut reader = BufReader::new(stream.try_clone().expect("failed to clone stream"));
    let mut response_stream = stream;

    loop {
        // 1. Parse a RESP frame
        let frame = match parse_frame(&mut reader) {
            Ok(f) => f,
            Err(e) if e.kind() == io::ErrorKind::UnexpectedEof => {
                println!("client disconnected.");
                return;
            }
            Err(e) => {
                eprintln!("Error reading RESP frame: {}", e);
                let reply = rivetdb::RespReply::Error("protocol error".into());
                let _ = response_stream.write_all(&reply.to_bytes());
                return;
            }
        };

        // 2. Convert frame -> ParsedCommand
        let cmd = match frame_to_command(frame) {
            Ok(c) => c,
            Err(msg) => {
                let reply = rivetdb::RespReply::Error(msg);
                let _ = response_stream.write_all(&reply.to_bytes());
                continue;
            }
        };

        println!("Received command: {} {:?}", cmd.name, cmd.args);

        // 3. Execute command with timing
        let cmd_name = cmd.name.clone();

        let start = Instant::now();
        let reply = std::panic::catch_unwind(|| process_command(cmd, &state));
        let duration = start.elapsed().as_nanos();

        let reply = match reply {
            Ok(r) => r,
            Err(_) => rivetdb::RespReply::Error("internal error".into()),
        };

        // Update observability metrics
        {
            let mut guard = state.lock().unwrap();

            *guard.command_count.entry(cmd_name.clone()).or_insert(0) += 1;
            *guard.command_time_ns.entry(cmd_name.clone()).or_insert(0) += duration;

            // Slow log (threshold: 1 ms)
            if duration > 1_000_000 {
                if guard.slowlog.len() == 128 {
                    guard.slowlog.pop_front();
                }
                guard.slowlog.push_back(rivetdb::storage::SlowLogEntry {
                    command: cmd_name,
                    duration_ns: duration,
                    timestamp: Instant::now(),
                });
            }
        }

        // 5. Send response
        let bytes = reply.to_bytes();
        if response_stream.write_all(&bytes).is_err() {
            eprintln!("Failed to write to client.");
            return;
        }
    }
}
