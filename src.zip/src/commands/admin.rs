use crate::protocol::RespReply;
use crate::storage::{SharedState, EvictionPolicy, estimate_value_size};
use super::ParsedCommand;
use super::expiry::is_expired;

pub fn stats(state: &SharedState) -> RespReply {
    let guard = state.lock().unwrap();

    let mut arr = Vec::new();
    arr.push(RespReply::Bulk(Some("expired_keys".into())));
    arr.push(RespReply::Integer(guard.expired_count as i64));

    for (cmd, count) in &guard.command_count {
        let total_time = guard.command_time_ns.get(cmd).unwrap_or(&0);
        let avg = if *count > 0 {
            total_time / (*count as u128)
        } else {
            0
        };

        arr.push(RespReply::Bulk(Some(format!("cmd:{}:count", cmd))));
        arr.push(RespReply::Integer(*count as i64));

        arr.push(RespReply::Bulk(Some(format!("cmd:{}:avg_ns", cmd))));
        arr.push(RespReply::Integer(avg as i64));
    }

    RespReply::Array(arr)
}

pub fn hotkeys(state: &SharedState) -> RespReply {
    let guard = state.lock().unwrap();

    let mut keys: Vec<_> = guard.key_access_count.iter().collect();
    keys.sort_by(|a, b| b.1.cmp(a.1));

    let mut result = Vec::new();
    for (k, v) in keys.into_iter().take(5) {
        result.push(RespReply::Bulk(Some(k.clone())));
        result.push(RespReply::Integer(*v as i64));
    }

    RespReply::Array(result)
}

pub fn memory(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() != 1 {
        return RespReply::Error("MEMORY requires key".into());
    }

    let key = &cmd.args[0];
    let mut guard = state.lock().unwrap();

    if is_expired(&mut guard, key) {
        return RespReply::Integer(0);
    }

    if guard.db.contains_key(key) {
        *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;
    }

    match guard.db.get(key) {
        Some(v) => RespReply::Integer(estimate_value_size(v) as i64),
        None => RespReply::Integer(0),
    }
}

pub fn slowlog(state: &SharedState) -> RespReply {
    let guard = state.lock().unwrap();
    let mut result = Vec::new();

    for entry in guard.slowlog.iter().rev() {
        result.push(RespReply::Bulk(Some(entry.command.clone())));
        result.push(RespReply::Integer(entry.duration_ns as i64));
    }

    RespReply::Array(result)
}

pub fn config(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() < 2 {
        return RespReply::Error("CONFIG GET|SET".into());
    }

    match cmd.args[0].as_str() {
        "GET" => {
            let guard = state.lock().unwrap();
            match cmd.args[1].as_str() {
                "maxmemory" => RespReply::Integer(guard.max_memory as i64),
                "eviction" => RespReply::Bulk(Some(guard.eviction_policy.as_str().into())),
                _ => RespReply::Bulk(None),
            }
        }

        "SET" => {
            let mut guard = state.lock().unwrap();
            match cmd.args[1].as_str() {
                "maxmemory" => {
                    guard.max_memory = cmd.args[2].parse().unwrap_or(guard.max_memory);
                    RespReply::Simple("OK".into())
                }
                "eviction" => {
                    guard.eviction_policy = match cmd.args[2].as_str() {
                        "lfu" => EvictionPolicy::AllKeysLFU,
                        "lru" => EvictionPolicy::AllKeysLRU,
                        "none" => EvictionPolicy::NoEviction,
                        _ => return RespReply::Error("unknown eviction policy".into()),
                    };
                    RespReply::Simple("OK".into())
                }
                _ => RespReply::Error("unknown config".into()),
            }
        }

        _ => RespReply::Error("CONFIG GET|SET".into()),
    }
}