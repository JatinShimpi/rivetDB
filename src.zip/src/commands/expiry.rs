use std::cmp::Reverse;
use std::thread;
use std::time::{Duration, Instant};
use crate::protocol::RespReply;
use crate::storage::{SharedState, ServerState};
use super::ParsedCommand;

pub fn is_expired(state: &mut ServerState, key: &str) -> bool {
    let now = Instant::now();
    let expired = state
        .expiries
        .iter()
        .any(|Reverse((t, k))| k == key && *t <= now);

    if expired {
        state.db.remove(key);
        state.key_access_count.remove(key);
        state.expired_count += 1;
    }

    expired
}

pub fn start_expiry_thread(state: SharedState) {
    thread::spawn(move || {
        loop {
            thread::sleep(Duration::from_millis(100));

            let mut guard = state.lock().unwrap();
            let now = Instant::now();

            loop {
                let next = match guard.expiries.peek() {
                    Some(Reverse((t, key))) => (*t, key.clone()),
                    None => break,
                };

                if next.0 > now {
                    break;
                }

                guard.expiries.pop();
                if guard.db.remove(&next.1).is_some() {
                    guard.key_access_count.remove(&next.1);
                    guard.expired_count += 1;
                }
            }
        }
    });
}

pub fn expire(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() != 2 {
        return RespReply::Error("EXPIRE requires key and seconds".into());
    }

    let key = &cmd.args[0];
    let seconds: u64 = match cmd.args[1].parse() {
        Ok(s) => s,
        Err(_) => return RespReply::Error("invalid expire time".into()),
    };

    let mut state = state.lock().unwrap();

    if !state.db.contains_key(key) {
        return RespReply::Integer(0);
    }

    let expire_at = Instant::now() + Duration::from_secs(seconds);
    state.expiries.push(Reverse((expire_at, key.clone())));

    RespReply::Integer(1)
}

pub fn ttl(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() != 1 {
        return RespReply::Error("TTL requires one key".into());
    }

    let key = &cmd.args[0];
    let mut guard = state.lock().unwrap();

    if !guard.db.contains_key(key) {
        return RespReply::Integer(-2);
    }

    let now = Instant::now();
    let mut ttl = None;

    for Reverse((t, k)) in guard.expiries.iter() {
        if k == key {
            if *t <= now {
                guard.db.remove(key);
                guard.expired_count += 1;
                return RespReply::Integer(-2);
            }
            ttl = Some(t.saturating_duration_since(now).as_secs() as i64);
            break;
        }
    }

    match ttl {
        Some(v) => RespReply::Integer(v),
        None => RespReply::Integer(-1),
    }
}