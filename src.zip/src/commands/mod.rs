mod basic;
mod string;
mod list;
mod set;
pub mod expiry;
mod admin;

use crate::storage::SharedState;
use crate::protocol::RespReply;

/// Parsed command: what the executor will see
pub struct ParsedCommand {
    pub name: String,
    pub args: Vec<String>,
}

pub fn process_command(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    match cmd.name.as_str() {
        "PING" => basic::ping(cmd),
        "DEL" => basic::del(cmd, state),
        "EXISTS" => basic::exists(cmd, state),

        "SET" => string::set(cmd, state),
        "GET" => string::get(cmd, state),
        "INCR" => string::incr(cmd, state),
        "DECR" => string::decr(cmd, state),

        "LPUSH" => list::lpush(cmd, state),
        "LLEN" => list::llen(cmd, state),
        "LRANGE" => list::lrange(cmd, state),

        "SADD" => set::sadd(cmd, state),
        "SREM" => set::srem(cmd, state),
        "SMEMBERS" => set::smembers(cmd, state),

        "EXPIRE" => expiry::expire(cmd, state),
        "TTL" => expiry::ttl(cmd, state),

        "STATS" => admin::stats(state),
        "HOTKEYS" => admin::hotkeys(state),
        "MEMORY" => admin::memory(cmd, state),
        "SLOWLOG" => admin::slowlog(state),
        "CONFIG" => admin::config(cmd, state),

        _ => RespReply::Error("unknown command".into()),
    }
}