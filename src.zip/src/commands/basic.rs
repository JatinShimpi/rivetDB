use crate::protocol::RespReply;
use crate::storage::SharedState;
use super::ParsedCommand;
use super::expiry::is_expired;

pub fn ping(cmd: ParsedCommand) -> RespReply {
    if cmd.args.is_empty() {
        RespReply::Simple("PONG".into())
    } else {
        RespReply::Simple(cmd.args[0].clone())
    }
}

pub fn del(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.is_empty() {
        return RespReply::Error("DEL requires at least one key".into());
    }

    let mut guard = state.lock().unwrap();
    let mut removed = 0;

    for key in &cmd.args {
        if guard.db.remove(key).is_some() {
            guard.key_access_count.remove(key);
            removed += 1;
        }
    }

    RespReply::Integer(removed)
}

pub fn exists(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    let mut guard = state.lock().unwrap();
    let mut count = 0;

    for key in &cmd.args {
        if !is_expired(&mut guard, key) && guard.db.contains_key(key) {
            *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;
            count += 1;
        }
    }

    RespReply::Integer(count)
}