use super::expiry::is_expired;
use super::ParsedCommand;
use crate::protocol::RespReply;
use crate::storage::evict_if_needed;
use crate::storage::{SharedState, ValueObject};

pub fn set(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() < 2 {
        return RespReply::Error("SET requires key and value".into());
    }

    let key = &cmd.args[0];
    let value = &cmd.args[1];

    let mut guard = state.lock().unwrap();

    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    guard
        .db
        .insert(key.clone(), ValueObject::String(value.clone()));

    evict_if_needed(&mut guard, Some(key));

    RespReply::Simple("OK".into())
}

pub fn get(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() < 1 {
        return RespReply::Error("GET requires key".into());
    }

    let key = &cmd.args[0];
    let mut guard = state.lock().unwrap();

    if is_expired(&mut guard, key) {
        return RespReply::Bulk(None);
    }

    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    match guard.db.get(key) {
        Some(ValueObject::String(v)) => RespReply::Bulk(Some(v.clone())),
        Some(_) => RespReply::Error("WRONGTYPE Operation against wrong kind of value".into()),
        None => RespReply::Bulk(None),
    }
}

pub fn incr(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() != 1 {
        return RespReply::Error("INCR requires one key".into());
    }

    let key = &cmd.args[0];
    let mut guard = state.lock().unwrap();

    if is_expired(&mut guard, key) {
        guard
            .db
            .insert(key.clone(), ValueObject::String("0".into()));
    }

    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    let value = guard
        .db
        .entry(key.clone())
        .or_insert_with(|| ValueObject::String("0".into()));

    match value {
        ValueObject::String(s) => {
            let num = match s.parse::<i64>() {
                Ok(n) => n,
                Err(_) => return RespReply::Error("value is not an integer".into()),
            };

            let new_val = num + 1;
            *s = new_val.to_string();
            RespReply::Integer(new_val)
        }
        _ => RespReply::Error("WRONGTYPE".into()),
    }
}

pub fn decr(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() != 1 {
        return RespReply::Error("DECR requires one key".into());
    }

    let key = &cmd.args[0];
    let mut guard = state.lock().unwrap();

    if is_expired(&mut guard, key) {
        guard
            .db
            .insert(key.clone(), ValueObject::String("0".into()));
    }

    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    let value = guard
        .db
        .entry(key.clone())
        .or_insert_with(|| ValueObject::String("0".into()));

    match value {
        ValueObject::String(s) => {
            let num = match s.parse::<i64>() {
                Ok(n) => n,
                Err(_) => return RespReply::Error("value is not an integer".into()),
            };

            let new_val = num - 1;
            *s = new_val.to_string();
            RespReply::Integer(new_val)
        }
        _ => RespReply::Error("WRONGTYPE".into()),
    }
}
