use std::collections::HashSet;
use crate::protocol::RespReply;
use crate::storage::{SharedState, ValueObject};
use crate::storage::evict_if_needed;
use super::ParsedCommand;
use super::expiry::is_expired;

pub fn sadd(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() < 2 {
        return RespReply::Error("SADD requires key and members".into());
    }

    let key = &cmd.args[0];
    let members = &cmd.args[1..];

    let mut guard = state.lock().unwrap();

    if is_expired(&mut guard, key) {
        guard.db.remove(key);
    }

    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    let added = {
        let entry = guard
            .db
            .entry(key.clone())
            .or_insert_with(|| ValueObject::Set(HashSet::new()));

        match entry {
            ValueObject::Set(s) => {
                let mut added = 0;
                for m in members {
                    if s.insert(m.clone()) {
                        added += 1;
                    }
                }
                added
            }
            _ => {
                return RespReply::Error("WRONGTYPE".into());
            }
        }
    };

    evict_if_needed(&mut guard, Some(key));

    RespReply::Integer(added)
}

pub fn srem(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() < 2 {
        return RespReply::Error("SREM requires key and members".into());
    }

    let key = &cmd.args[0];
    let members = &cmd.args[1..];

    let mut guard = state.lock().unwrap();

    if is_expired(&mut guard, key) {
        return RespReply::Integer(0);
    }

    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    match guard.db.get_mut(key) {
        Some(ValueObject::Set(s)) => {
            let mut removed = 0;
            for m in members {
                if s.remove(m) {
                    removed += 1;
                }
            }
            RespReply::Integer(removed)
        }
        None => RespReply::Integer(0),
        _ => RespReply::Error("WRONGTYPE".into()),
    }
}

pub fn smembers(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() != 1 {
        return RespReply::Error("SMEMBERS requires one key".into());
    }

    let key = &cmd.args[0];
    let mut guard = state.lock().unwrap();

    if is_expired(&mut guard, key) {
        return RespReply::Array(vec![]);
    }

    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    match guard.db.get(key) {
        Some(ValueObject::Set(s)) => {
            let members = s.iter().map(|v| RespReply::Bulk(Some(v.clone()))).collect();
            RespReply::Array(members)
        }
        None => RespReply::Array(vec![]),
        _ => RespReply::Error("WRONGTYPE".into()),
    }
}