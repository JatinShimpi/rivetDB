use std::collections::LinkedList;
use crate::protocol::RespReply;
use crate::storage::{SharedState, ValueObject};
use crate::storage::evict_if_needed;
use super::ParsedCommand;
use super::expiry::is_expired;

pub fn lpush(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() < 2 {
        return RespReply::Error("LPUSH requires key and value".into());
    }

    let key = &cmd.args[0];
    let value = &cmd.args[1];

    let mut guard = state.lock().unwrap();

    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    let new_len = {
        let entry = guard
            .db
            .entry(key.clone())
            .or_insert_with(|| ValueObject::List(LinkedList::new()));

        match entry {
            ValueObject::List(list) => {
                list.push_front(value.clone());
                list.len() as i64
            }
            _ => {
                return RespReply::Error(
                    "WRONGTYPE Operation against wrong kind of value".into(),
                );
            }
        }
    };

    evict_if_needed(&mut guard, Some(key));

    RespReply::Integer(new_len)
}

pub fn llen(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() != 1 {
        return RespReply::Error("LLEN requires one key".into());
    }

    let mut guard = state.lock().unwrap();

    if is_expired(&mut guard, &cmd.args[0]) {
        return RespReply::Integer(0);
    }

    let key = &cmd.args[0];
    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    match guard.db.get(&cmd.args[0]) {
        Some(ValueObject::List(list)) => RespReply::Integer(list.len() as i64),
        None => RespReply::Integer(0),
        _ => RespReply::Error("WRONGTYPE".into()),
    }
}

pub fn lrange(cmd: ParsedCommand, state: &SharedState) -> RespReply {
    if cmd.args.len() != 3 {
        return RespReply::Error("LRANGE requires key start stop".into());
    }

    let key = &cmd.args[0];
    let start: isize = cmd.args[1].parse().unwrap_or(0);
    let stop: isize = cmd.args[2].parse().unwrap_or(-1);

    let mut guard = state.lock().unwrap();
    if is_expired(&mut guard, key) {
        return RespReply::Array(vec![]);
    }

    *guard.key_access_count.entry(key.clone()).or_insert(0) += 1;

    let list = match guard.db.get(key) {
        Some(ValueObject::List(l)) => l,
        None => return RespReply::Array(vec![]),
        _ => return RespReply::Error("WRONGTYPE".into()),
    };

    let len = list.len() as isize;
    let s = if start < 0 { len + start } else { start }.max(0);
    let e = if stop < 0 { len + stop } else { stop }.min(len - 1);

    let mut result = Vec::new();

    for (i, val) in list.iter().enumerate() {
        let i = i as isize;
        if i >= s && i <= e {
            result.push(RespReply::Bulk(Some(val.clone())));
        }
    }

    RespReply::Array(result)
}