use super::state::ServerState;
use super::value::estimate_value_size;

#[derive(Debug, PartialEq)]
pub enum EvictionPolicy {
    NoEviction,
    AllKeysLFU,
    AllKeysLRU,
}

impl EvictionPolicy {
    pub fn as_str(&self) -> &'static str {
        match self {
            EvictionPolicy::NoEviction => "noeviction",
            EvictionPolicy::AllKeysLFU => "allkeys-lfu",
            EvictionPolicy::AllKeysLRU => "allkeys-lru",
        }
    }
}

pub fn current_memory_usage(state: &ServerState) -> usize {
    state.db.values().map(estimate_value_size).sum()
}

pub fn evict_if_needed(state: &mut ServerState, protected: Option<&str>) {
    if state.eviction_policy == EvictionPolicy::NoEviction {
        return;
    }

    let mut used = current_memory_usage(state);

    while used > state.max_memory && !state.db.is_empty() {
        let victim = match state.eviction_policy {
            EvictionPolicy::AllKeysLFU | EvictionPolicy::AllKeysLRU => state
                .key_access_count
                .iter()
                .filter(|(k, _)| Some(k.as_str()) != protected)
                .min_by_key(|(_, count)| *count)
                .map(|(k, _)| k.clone()),

            EvictionPolicy::NoEviction => None,
        };

        let Some(key) = victim else { break };

        if let Some(val) = state.db.remove(&key) {
            used -= estimate_value_size(&val);
        }

        state.key_access_count.remove(&key);
    }
}
