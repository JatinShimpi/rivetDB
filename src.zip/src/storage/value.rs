use std::collections::{HashSet, LinkedList};

pub enum ValueObject {
    String(String),
    List(LinkedList<String>),
    Set(HashSet<String>),
}

pub fn estimate_value_size(v: &ValueObject) -> usize {
    match v {
        ValueObject::String(s) => s.len(),
        ValueObject::List(l) => l.iter().map(|s| s.len()).sum(),
        ValueObject::Set(s) => s.iter().map(|s| s.len()).sum(),
    }
}
