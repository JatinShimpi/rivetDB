mod eviction;
mod state;
mod value;

pub use eviction::{current_memory_usage, evict_if_needed, EvictionPolicy};
pub use state::{ServerState, SharedState, SlowLogEntry};
pub use value::{estimate_value_size, ValueObject};
