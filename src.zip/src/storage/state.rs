use std::collections::{HashMap, VecDeque, BinaryHeap};
use std::cmp::Reverse;
use std::sync::{Arc, Mutex};
use std::time::Instant;

use super::value::ValueObject;
use super::eviction::EvictionPolicy;

pub type ExpiryHeap = BinaryHeap<Reverse<(Instant, String)>>;
pub type SharedState = Arc<Mutex<ServerState>>;

pub struct SlowLogEntry {
    pub command: String,
    pub duration_ns: u128,
    pub timestamp: Instant,
}

pub struct ServerState {
    pub db: HashMap<String, ValueObject>,
    pub expiries: ExpiryHeap,
    pub expired_count: u64,

    // Observability
    pub command_count: HashMap<String, u64>,
    pub command_time_ns: HashMap<String, u128>,
    pub slowlog: VecDeque<SlowLogEntry>,
    pub key_access_count: HashMap<String, u64>,

    pub max_memory: usize, // bytes
    pub eviction_policy: EvictionPolicy,
}